
# coding: utf-8

# In[ ]:


file = open('video1_csv.csv', "r")
time_stamp = []
for line in file:
    #print(line)
    line = line.split(",")
    line = [line[9], float(line[5]), float(line[6])]
    time_stamp.append(line)
#print(time_stamp)

for i in time_stamp:
    if "failure" in i[0]:
        i[0] = "failure"
    elif "success" in i[0]:
        i[0] = "success"
print(time_stamp)

shots = {}

for i in time_stamp:
    key = i[0]
    value = [i[1], i[2]]
    
    if key not in shots:
        shots[key] = []
    if value not in shots[key]:
        shots[key].append(value)
#print(shots,"\n")


#for j in shots["failure"]:
    #print(j)
    
    #print(j[0], j[1])
    


# In[ ]:


import cv2

cap = cv2.VideoCapture('A:/Study/Python/data/video1.mp4')
fps = cap.get(cv2.CAP_PROP_FPS)
print(fps)
timestamps = [cap.get(cv2.CAP_PROP_POS_MSEC)]

#calc_timestamps = [0.0]
count = 0
frame_ctr = 0


while(cap.isOpened()):
    frame_exists, curr_frame = cap.read()
    if frame_exists:
        if cap.get(cv2.CAP_PROP_POS_MSEC) >= 2781774.014  and cap.get(cv2.CAP_PROP_POS_MSEC) <= 2783218.633 :
            #timestamps.append(cap.get(cv2.CAP_PROP_POS_MSEC))
            #calc_timestamps.append(calc_timestamps[-1] + 1000/fps)
            cv2.imwrite('A:/Study/Python/data/failure/frame%d.jpg' % frame_ctr, curr_frame)
            frame_ctr += 1
            curr_frame = cap.read()
            count += 1

        #else:
         #   if cap.get(cv2.CAP_PROP_POS_MSEC) >= j[0] and cap.get(cv2.CAP_PROP_POS_MSEC) <= j[1]:
          #      timestamps.append(cap.get(cv2.CAP_PROP_POS_MSEC))
#
                #calc_timestamps.append(calc_timestamps[-1] + 1000/fps)
 #               cv2.imwrite('A:/Study/Python/data/success/frame%d.jpg' % frame_ctr, curr_frame)
  #              frame_ctr += 1
   #             curr_frame = cap.read()
    #            count += 1

    else:
        break

cap.release()
print(timestamps)

